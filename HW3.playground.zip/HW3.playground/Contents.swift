import UIKit

/*
Опишите в программе два класса: Человек (ФИО, возраст, паспорт), Паспорт (Серия, Номер, дата выдачи, Человек) и инициализируйте их.*/


class Pasport {

    
    var series: Int
    var number: Int
    var date: Int
    weak var person: Person?
    
    init (series: Int, number: Int, date: Int, person: Person?) {
        self.series = series
        self.number = number
        self.date = date
        self.person = person
    }
}

class Person {
    var surname: String
    var name: String
    var patronymic: String
    var fullName: String {
        get {
            return "\(surname) \(name) \(patronymic)"}
    }
    var age: Int
    weak var paspotr: Pasport?
    
    init (surname: String, name: String, patronymic: String, age: Int, paspotr: Pasport?) {
        self.surname = surname
        self.name = name
        self.patronymic = patronymic
        self.age = age
        self.paspotr = paspotr
    }
}


var person1: Person?
var pasport1: Pasport?

func create () {
    
    pasport1 = Pasport(series: 5003, number: 3489789, date: 18011953, person: person1)
    person1 = Person(surname: "Sidorov", name: "Dmitrivv", patronymic: "Vladimirovich", age: 23, paspotr: pasport1)
    
}

create()

extension Person: CustomDebugStringConvertible {
    var debugDescription: String {
        
        //return "\(self.fullName) age: \(self.age), pasport: \(String(describing: self.paspotr ?? nil))"
         return "\(self.fullName) age: \(self.age), pasport: \(self.paspotr!))"
    }
    
}
    
extension Pasport: CustomDebugStringConvertible {
    var debugDescription: String {
        return "\(self.series) \(self.number) \(self.date)"
    }
}

if  person1 != nil {
    print(person1!)
} else {
    print("optional")
}
    


    

